RSS_SOURCES = [
    "https://rsute.ru/sad-ogorod/feed",
    "https://thegardeningdad.com/feed",
    "https://finegardening.com/feed",
]
